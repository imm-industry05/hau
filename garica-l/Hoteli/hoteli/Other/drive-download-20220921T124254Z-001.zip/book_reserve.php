<?php
    session_start();
    require_once('config.php');
    if(isset($_SESSION['email']))
    {
       $sql = "SELECT * FROM userdata WHERE email='{$_SESSION["email"]}'";
       $result=mysqli_query($conn,$sql);
       $row=mysqli_fetch_array($result);

       if($row["type"]=="User")
       {
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <title>Hoteli</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!--Icon Offline-->
        <link href='css/all.min.css' rel='stylesheet'>
        <link href='css/fontawesome.min.css' rel='stylesheet'>
        <!--Bootstrap Offline-->
        <link href='css/bootstrap.css' rel='stylesheet'>
        <script src="js/bootstrap.js"></script>
        <!--Shortcut Icon-->
        <link rel="shortcut icon" type="x-icon" href="assets/logobg.png">
        <!--Pop Up-->
        <script src="js/pop_up.js"></script>
        <style>
            /* UTILITIES */
            *{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            nav a{
                text-decoration: none;
            }
            nav li{
                list-style: none;
            }
             /* NAVBAR STYLING STARTS */
             .navbar{
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 0 20px;
                background-color: #fff;
                box-shadow: 0 14px 28px rgba(0,0,0,0.25), 
                    0 10px 10px rgba(0,0,0,0.22);
                color: #000;
            }
            .nav-links a{
                color: #000;
            }
            /* NAVBAR MENU */
            .menu{
                display: flex;
                gap: 1em;
                font-size: 18px;
            }
            .menu li:hover{
                background-color: #D3D3D3;
                border-radius: 1px;
                transition: 0.3s ease;
            }
            .menu li{
                padding: 10px 10px 8px;
                margin-top:8px;
            }
            /*End of Navigation */
            /*Container*/
            .date1 input[type=submit], .date2 input[type=submit], .date3 input[type=submit], .date4 input[type=submit], .date5 input[type=submit], .date6 input[type=submit]{
                margin-left:60px;
            }
            label{
                font-weight: bolder;
            }
            .left-data1 img{
                width: 180px;
                height: 150px;
                position: absolute;
                margin:80px 0 0 80px;
            }
            .right-data1{
                width: 40%;
                position: absolute;
                margin:80px 0 0 280px;
            }
            .date1{
                position: absolute;
                margin:80px 0 0 830px;
            }
            .left-data2 img{
                width: 180px;
                height: 150px;
                position: absolute;
                margin:300px 0 0 -147px;
            }
            .right-data2{
                width: 40%;
                position: absolute;
                margin:300px 0 0 53px;
            }
            .date2{
                position: absolute;
                margin:300px 0 0 600px;
            }
            .left-data3 img{
                width: 180px;
                height: 150px;
                position: absolute;
                margin:520px 0 0 -374px;
            }
            .right-data3{
                width: 40%;
                position: absolute;
                margin:520px 0 0 -174px;
            }
            .date3{
                position: absolute;
                margin:520px 0 0 373px;
            }
            .left-data4 img{
                width: 180px;
                height: 150px;
                position: absolute;
                margin:740px 0 0 -601px;
            }
            .right-data4{
                width: 40%;
                position: absolute;
                margin:740px 0 0 -401px;
            }
            .date4{
                position: absolute;
                margin:740px 0 0 146px;
            }
            .left-data5 img{
                width: 180px;
                height: 150px;
                position: absolute;
                margin:960px 0 0 -828px;
            }
            .right-data5{
                width: 40%;
                position: absolute;
                margin:960px 0 0 -628px;
            }
            .date5{
                position: absolute;
                margin:960px 0 0 -84px;
            }
            .left-data6 img{
                width: 180px;
                height: 150px;
                position: absolute;
                margin:1180px 0 0 -1055px;
            }
            .right-data6{
                width: 40%;
                position: absolute;
                margin:1180px 0 0 -855px;
            }
            .date6{
                position: absolute;
                margin:1180px 0 0 -311px;
            }
        </style>
    </head>
    <body>
        <nav class="navbar">
            <li><a href="user.php">
                <img src="assets/logobg.png" alt="Hoteli" height="25px">
            </a></li>
            <!-- NAVIGATION MENU -->
            <ul class="nav-links">
                <div class="menu">
                    <li><a href="user.php">Home</a></li>
                    <li><a href="#">Book Reservation</a></li>
                    <li><a href="feedback.php">Feedback</a></li>
                    <li><a href="user_account_settings.php">Account Setting</a></li>
                    <li><a href="logout.php?logout">Log out</a></li>
                </div>
            </ul>
        </nav>

        <div class="section">
            <div class="container-9">
                <div class="row">
                    <?php
                        $sql = "SELECT * FROM userdata WHERE email='{$_SESSION["email"]}'";
                            $result = mysqli_query($conn, $sql);
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="col">
                        <form action="process.php" method="POST">
                            <div class="left-data1">
                                <img src="assets/standardRoom.jpg" alt="Standard Hoteli Room">
                            </div>
                            <div class="right-data1">
                                <dl>
                                    <dt>Standard Hoteli Room</dt>
                                        <dd>
                                            In comparison to most hotel rooms, Standard Hoteli Room tend to be larger than their more basic counterparts. Whereas standard hotel rooms are typically separated into two main areas (bedroom & bathroom), standard suites usually include a separate living space.
                                        </dd>
                                </dl>
                            </div>
                            <div class="date1">
                                <label>Date and Time</label><br>
                                <input type="datetime-local" name="dnt1"><br><br>
                                <input type="submit" name="booknow1" class="btn btn-warning" onclick="return confirm('Are you sure, you want to Book this Offer?');" value="Book Now"/>
                            </div>
                        </form>
                    </div>
                    <div class="col">
                        <form action="process.php" method="POST">
                            <div class="left-data2">
                                <img src="assets/juniorRoom.jfif" alt="Junior Hoteli Room">
                            </div>
                            <div class="right-data2">
                                <dl>
                                    <dt>Junior Hoteli Room</dt>
                                        <dd>
                                            These are typically smaller versions of Standard Hoteli Room. While the layout likely denotes a specific space intended for sleeping, as well as a designated living area, the two may not be physically separated by a barrier. In Junior Hoteli Room, the living space may be a smaller extension of the bedroom area that doesn't come with a separate dining space.
                                        </dd>
                                </dl>
                            </div>
                            <div class="date2">
                                <label>Date and Time</label><br>
                                <input type="datetime-local" name="dnt2"><br><br>
                                <input type="submit" name="booknow2" class="btn btn-warning" onclick="return confirm('Are you sure, you want to Book this Offer?');" value="Book Now"/>
                            </div>
                        </form>
                    </div>
                    <div class="col">
                        <form action="process.php" method="POST">
                            <div class="left-data3">
                                <img src="assets/presidentialRoom.jpg" alt="Presidential Hoteli Room">
                            </div>
                            <div class="right-data3">
                                <dl>
                                    <dt>Presidential Hoteli Room</dt>
                                        <dd>
                                            Presidential Hoteli Room are known for being some of the most impressive. If a hotel offers this room type, there are usually only one or two available in the entire hotel — even with the largest brands. Presidential Hoteli Room are some of the most expensive hotel rooms available for travelers to book on the entire market.
                                        </dd>
                                </dl>
                            </div>
                            <div class="date3">
                                <label>Date and Time</label><br>
                                <input type="datetime-local" name="dnt3"><br><br>
                                <input type="submit" name="booknow3" class="btn btn-warning" onclick="return confirm('Are you sure, you want to Book this Offer?');" value="Book Now"/>
                            </div>
                        </form>
                    </div>
                    <div class="col">
                        <form action="process.php" method="POST">
                            <div class="left-data4">
                                <img src="assets/penthouseRoom.jpg" alt="Penthouse Hoteli Room">
                            </div>
                            <div class="right-data4">
                                <dl>
                                    <dt>Penthouse Hoteli Room</dt>
                                        <dd>
                                            Penthouse Hoteli Room are usually located on the top floor of a luxury building and can take up the entire floor. Hotels that offer these accommodations are often found in the heart of iconic cities.
                                        </dd>
                                </dl>
                            </div>
                            <div class="date4">
                                <label>Date and Time</label><br>
                                <input type="datetime-local" name="dnt4"><br><br>
                                <input type="submit" name="booknow4" class="btn btn-warning" onclick="return confirm('Are you sure, you want to Book this Offer?');" value="Book Now"/>
                            </div>
                        </form>
                    </div>
                    <div class="col">
                        <form action="process.php" method="POST">
                            <div class="left-data5">
                                <img src="assets/honeymoonRoom.jpg" alt="Honeymoon Hoteli Room">
                            </div>
                            <div class="right-data5">
                                <dl>
                                    <dt>Honeymoon Hoteli Room</dt>
                                        <dd>
                                            Designed with couples in mind, Honeymoon Hoteli Room are also known as romance room. Honeymoon Hoteli Room usually offer amenities, services, and special accommodations related to romance. Guests may arrive to find champagne, roses, chocolates, and fresh flowers in their room. 
                                        </dd>
                                </dl>
                            </div>
                            <div class="date5">
                                <label>Date and Time</label><br>
                                <input type="datetime-local" name="dnt5"><br><br>
                                <input type="submit" name="booknow5" class="btn btn-warning" onclick="return confirm('Are you sure, you want to Book this Offer?');" value="Book Now"/>
                            </div>
                        </form>
                    </div>
                    <div class="col">
                        <form action="process.php" method="POST">
                            <div class="left-data6">
                                <img src="assets/bridalRoom.jpeg" alt="Bridal Hoteli Room">
                            </div>
                            <div class="right-data6">
                                <dl>
                                    <dt>Bridal Hoteli Room</dt>
                                        <dd>
                                            Hotels that specialize in wedding services and accommodation often offer bridal suites to help the bridal party prepare for the big day.
                                        </dd>
                                </dl>
                            </div>
                            <div class="date6">
                                <label>Date and Time</label><br>
                                <input type="datetime-local" name="dnt6"><br><br>
                                <input type="submit" name="booknow6" class="btn btn-warning" onclick="return confirm('Are you sure, you want to Book this Offer?');" value="Book Now"/>
                            </div>
                        </form>
                    </div>
                    <?php
                            }
                        }
                    ?>
                </div>
            </div>
            <div class="container-3">

            </div>
        </div>
        
    </body>
<?php
    }else{
        header("location:admin.php");
    }
        }
        else
        {
         header("location:index.php");
    }
?>
</html>